"""Conservative public-source link discovery. Not an official KHNP API.

No claim of real-time availability, application eligibility or closing dates.
If official page is unavailable/changes structure, keep previous data and mark stale.
"""
import json
import re
import urllib.request
from datetime import datetime, timezone
from html.parser import HTMLParser
from pathlib import Path
from urllib.parse import urljoin, urlparse

ROOT = Path(__file__).resolve().parents[1]
DEST = ROOT / 'data' / 'notices.json'
SOURCE = 'https://www.khnp.co.kr/recruit'
ALLOWED = {'www.khnp.co.kr', 'khnp.co.kr'}
KEYWORDS = ('채용', '모집', '고졸', '신입', '특별전형', '일반전형')

class LinkParser(HTMLParser):
    def __init__(self):
        super().__init__()
        self.links = []
        self.href = None
        self.text = []
    def handle_starttag(self, tag, attrs):
        if tag == 'a':
            self.href = dict(attrs).get('href')
            self.text = []
    def handle_data(self, data):
        if self.href is not None:
            self.text.append(data)
    def handle_endtag(self, tag):
        if tag == 'a' and self.href is not None:
            self.links.append((self.href, ' '.join(' '.join(self.text).split())))
            self.href = None
            self.text = []

def main():
    old = json.loads(DEST.read_text(encoding='utf-8')) if DEST.exists() else {'notices': []}
    now = datetime.now(timezone.utc).isoformat(timespec='seconds')
    try:
        req = urllib.request.Request(SOURCE, headers={'User-Agent': 'KHNP-Gaja-Education-LinkMonitor/1.0'})
        with urllib.request.urlopen(req, timeout=20) as res:
            content = res.read(2_000_000).decode('utf-8', errors='replace')
        parser = LinkParser()
        parser.feed(content)
        found = {}
        for href, title in parser.links:
            if not title or len(title) > 180 or not any(k in title for k in KEYWORDS):
                continue
            url = urljoin(SOURCE, href)
            parsed = urlparse(url)
            if parsed.scheme != 'https' or parsed.hostname not in ALLOWED:
                continue
            if url.rstrip('/') == SOURCE.rstrip('/'):
                continue
            if href.startswith('javascript:') or re.search(r'(login|logout|privacy|policy)', url, re.I):
                continue
            found[url] = {'title': title, 'url': url, 'source': '한국수력원자력 홈페이지', 'discovered_at': now[:10], 'verification': '공식 페이지에서 내용 확인 필요'}
        if not found:
            raise ValueError('공고 링크를 식별하지 못했습니다. 페이지 구조 확인이 필요합니다.')
        prior = {x['url']: x for x in old.get('notices', []) if x.get('url')}
        for url, item in found.items():
            if url in prior:
                item['discovered_at'] = prior[url].get('discovered_at', item['discovered_at'])
        # Only expose candidate links. Never invent deadlines, statuses, or requirements.
        data = {'checked_at': now, 'status': 'candidate_links', 'message': '공식 페이지에서 발견한 관련 링크입니다. 실제 채용 공고인지, 접수 중인지 반드시 원문에서 확인하세요.', 'notices': list(found.values())[:30]}
    except Exception as exc:
        data = {'checked_at': now, 'status': 'error', 'message': '자동 확인에 실패했습니다. 공식 채용 홈페이지에서 직접 확인하세요.', 'notices': old.get('notices', []), 'error_type': type(exc).__name__}
    DEST.write_text(json.dumps(data, ensure_ascii=False, indent=2) + '\n', encoding='utf-8')
    print(data['status'], len(data['notices']))

if __name__ == '__main__':
    main()
